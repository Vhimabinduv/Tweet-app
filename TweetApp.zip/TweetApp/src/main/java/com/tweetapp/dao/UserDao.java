package com.tweetapp.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.sql.Date;
import java.util.Properties;

import com.tweetapp.model.UserModel;
import com.tweetapp.pages.UserRegistration;

public class UserDao {
	
	 private static final String DATABASE_DRIVER_CLASS="jdbc.driver";
	private static final String DATABASE_USERNAME="jdbc.username";
	private static final String DATABASE_PASSWORD="jdbc.password";
	private static final String DATABASE_URL ="jdbc.url";
	
	private static Connection connection = null;
	private static Properties properties = null;
	
	static
	{
		try {
			properties = new Properties();
			properties.load(new FileInputStream("src/main/resources/db.properties"));
			Class.forName(properties.getProperty(DATABASE_DRIVER_CLASS));
			connection = DriverManager.getConnection(properties.getProperty(DATABASE_URL),properties.getProperty(DATABASE_USERNAME) , properties.getProperty(DATABASE_PASSWORD) );
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection()
	{
		return connection;
	}
	
	
}
