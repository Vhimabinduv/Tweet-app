package com.tweetapp.pages;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import com.tweetapp.model.UserModel;
import com.tweetapp.service.UserServiceImpl;

public class UserRegistration {
	
	Scanner scan= new Scanner(System.in);
	
	UserServiceImpl service= new UserServiceImpl();
	
    
    public UserModel register() throws Exception
    {
    	UserModel user =new UserModel();
    	System.out.println("Please Enter Your firstname Required");
    	String Fname =scan.nextLine();
		user.setFirstname(Fname);
    	System.out.println("Please Enter Your lastname Optional");
    	String Lname=scan.nextLine();
		user.setLastname(Lname);
		System.out.println("Please Enter your Dob");
		String d1=scan.nextLine();
		SimpleDateFormat format= new SimpleDateFormat("dd-MM-yyyy");
		Date date=format.parse(d1);
		user.setDob(date);
		System.out.println("Please Enter your Gender");
		String gender=scan.nextLine();
		user.setGender(gender);
		System.out.println("Please Enter your Mail in useremail@xyz.com format");
		String emailAddress=scan.nextLine();
		user.setGmail(emailAddress);
		System.out.println("Please Enter your Password");
		String password=scan.nextLine();
		user.setPassword(password);
		return user;
    }
}
