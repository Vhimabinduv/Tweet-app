package com.tweetapp.pages;

import java.util.Scanner;


import com.tweetapp.exception.UserNotFoundException;
import com.tweetapp.model.UserModel;
import com.tweetapp.service.UserServiceImpl;

public class UserLogin {
	
	Scanner scan  = new Scanner(System.in);
	private String username;
	
	public boolean login() throws Exception
	{
		boolean success=false;
		UserModel um = new UserModel();
		UserServiceImpl service= new UserServiceImpl();
		System.out.println("Enter Username OR email format as useremail@xyz.com");
		 username=scan.nextLine();
		 String status="YouLoggedIn";
		try
    	{
    		if(service.validateUser(username)==true)
    		{
    			System.out.println("Please Enter your Password");
    			String pwd=scan.nextLine();
    			if(service.validatePassword(username).equals(pwd)) 
    			{
    				service.setLoginStatus(username, status);
    				success=true;
    			}
    			else
    			{
    				System.out.println("please enter valid password");
    			}
    		}
    	}
		catch (UserNotFoundException ex) 
    	{
            System.err.print(ex);
            System.out.println("--------------");
        }
		return success;
	}
	
	public String getUser()
	{
		return username;
	}
}
