package com.tweetapp.pages;

import java.util.Scanner;

import com.tweetapp.model.TweetModel;
import com.tweetapp.model.UserModel;

public class TweetPage 
{
	Scanner scan  = new Scanner(System.in);
	
	public TweetModel postTweet()
	{
		TweetModel tweetModel = new TweetModel();
		System.out.println("enter your tweet");
		String tweet=scan.nextLine();
		tweetModel.setTweet(tweet);
		System.out.println("enter your email");
		String email=scan.nextLine();
		tweetModel.setEmail(email);
		return tweetModel;
	}
}
