package com.tweetapp.pages;


import java.util.Scanner;
import com.tweetapp.exception.UserNotFoundException;
import com.tweetapp.model.UserModel;
import com.tweetapp.service.UserServiceImpl;

public class ForgotPassword {
	
	Scanner scan  = new Scanner(System.in);
	UserServiceImpl service= new UserServiceImpl();
	UserModel user = new UserModel();
	
	
	public void password() throws  Exception 
	{
		
		System.out.println(" please Enter username/emailaddress");
		String username=scan.nextLine();
		try
    	{
    		if(service.validateUser(username)==true)
    		{
    			System.out.println("please Enter NewPassword");
        		String newpwd=scan.nextLine();
        		service.updatepassword(username,newpwd);
    		}
    	}
    	catch (UserNotFoundException ex) 
    	{
            System.err.print(ex);
            System.out.println("please enter valid username");
    	}
	}
	public void resetPassword() throws Exception
	{
		System.out.println("Enter username/email");
		String username=scan.nextLine();
		try
    	{
    		if(service.validateUser(username)==true)
    		{
    			System.out.println("enter old password");
    			String oldpwd=scan.nextLine();
    			System.out.println("enter new password");
    			String newpwd=scan.nextLine();
    			service.updatepassword(username,newpwd);
    		}
    	}
		catch (UserNotFoundException ex) 
    	{
            System.err.print(ex);
            System.out.println("please enter valid username");
    	}
	}
}
