package com.tweetapp.service;

import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.tweetapp.dao.UserDao;
import com.tweetapp.exception.UserNotFoundException;
import com.tweetapp.model.TweetModel;
import com.tweetapp.model.UserModel;


public class UserServiceImpl implements IUserService {
	
	UserDao userdao=new UserDao();

	Connection connection = UserDao.getConnection();
	
	Statement statement =null;

	
	public void insert(UserModel user) throws SQLException 
	{
		System.out.println("Inserting records into the table...");
		  String sql = "insert into user(firstname, lastname,gender,dob,email,password) values(?,?,?,?,?,?)";
		  PreparedStatement statement = connection.prepareStatement(sql);
		
		 String fname=user.getFirstname();
		 String lname=user.getLastname();
		 String gender=user.getGender();
		 String gmail=user.getGmail();
		 String pwd=user.getPassword();
		 Date d1=user.getDob();
		 java.sql.Date sqlDate = new java.sql.Date(d1.getTime());
		 
		  statement.setString(1,fname);
		  statement.setString(2,lname);
		  statement.setString(3,gender);
		  statement.setDate(4, sqlDate);
		  statement.setString(5,gmail);
		  statement.setString(6,pwd);
		  
		  int rowsInserted = statement.executeUpdate();
		  if (rowsInserted > 0) {
		      System.out.println("A new user was inserted successfully!");
		  
		  }  
	}

	public void updatepassword(String username,String pwd) throws SQLException
	{
		
		String sqlUpdateQuery = "UPDATE user SET password = ? WHERE email = ?";
                 
        PreparedStatement statement = connection.prepareStatement(sqlUpdateQuery);
        statement.setString(1, pwd);
        statement.setString(2, username);
       int updatedRows= statement.executeUpdate();
       if (updatedRows > 0) 
       {
		      System.out.println("password updated successfully!");
		  
		}
        
	}

	
	public boolean validateUser(String email) throws Exception
	{
		boolean userExists=false;
		
		String sqlValidate = "select * from user where email = ?";
		PreparedStatement statement = connection.prepareStatement(sqlValidate);

		  statement.setString(1, email);
		  ResultSet r1=statement.executeQuery();
		  if(r1.next()) 
		  {
		    userExists = true;
		  }else
		  {
			  throw new UserNotFoundException(
		                "Could not find user with ID " + email);
		  }
		  return userExists;
	}
	
	public String validatePassword(String email) throws Exception
	{
        String passwordQuery = "select password from user where email =?";
       
            PreparedStatement ps = connection.prepareStatement(passwordQuery);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            rs.next();
            String pass=rs.getString("password");
            return pass;
     }

	
	public void insertTweet(TweetModel tweet) throws SQLException 
	{
		System.out.println("Inserting records into the table...");
		  String sqlInsert = "insert into Tweet(tweet,email) values(?,?)";
		  PreparedStatement statement = connection.prepareStatement(sqlInsert);
		
		 String tweetinformation=tweet.getTweet();
		 String gmailAddress=tweet.getEmail();
		 statement.setString(1,tweetinformation);
		 statement.setString(2,gmailAddress);
		 int rowsInserted = statement.executeUpdate();
		  if (rowsInserted > 0)
		  {
		      System.out.println("Tweet was inserted successfully!");
		  }  
	}

	
	public void viewAllTweets() throws SQLException
	{
		statement = connection.createStatement();
		String sqlView = "SELECT tweet,email FROM Tweet";
	      ResultSet rs = statement.executeQuery(sqlView);
	      while(rs.next()){

	        
	         String tweet = rs.getString("tweet");
	         String email = rs.getString("email");


	        
	         System.out.print("Tweet: " + tweet);
	         System.out.println(", mail: " + email);
	      }
	      rs.close();
	}

	
	public void viewAllUsers() throws SQLException
	{
		statement = connection.createStatement();
		String sql = "SELECT  firstname,lastname,gender,dob,email,password from user";
	      ResultSet rs = statement.executeQuery(sql);
	      // Extract data from result set
	      while(rs.next()){
	         //Retrieve by column name
	         String fname= rs.getString("firstname");
	         String lname = rs.getString("lastname");
	         String gender=rs.getString("gender");
	         String dob=rs.getString("dob");
	         String email=rs.getString("email");
	         String pwd=rs.getString("password");
	         		//Display values
	         System.out.print("firstname: " +fname);
	         System.out.println(", lastname: " + lname);
	         System.out.println("gender: " + gender);
	         System.out.println("dob: " + dob);
	         System.out.println("email: " + email);
	         System.out.println("password: " + pwd);
	      }
	      rs.close();
	}
	
	public void viewMyTweet(String username) throws SQLException
	{

		statement = connection.createStatement();
		String sql = "select * from tweet where email = ? ";
	    PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, username);
		ResultSet rs = statement.executeQuery();
	    while(rs.next())
	    {
	    	 String tweet = rs.getString("tweet");
	         String email = rs.getString("email");

	         System.out.print("Tweet: " + tweet);
	         System.out.println(", mail: " + email);
	      }
	      rs.close();
	}
	
	public void setLoginStatus(String mail,String status) {
		
		String queryStatus = "update user set status =? where email =?";

		 try {
			 PreparedStatement ps = connection.prepareStatement(queryStatus);
			 ps.setString(1,status);
			 ps.setString(2,mail);
			 int count = ps.executeUpdate();
			 if (count > 0)
				 System.out.println("Login/logout status updated");
			 
		 } 
		 catch (SQLException e) 
		 {
			 e.printStackTrace();
		}
		
		}
}




