package com.tweetapp.service;

import java.sql.SQLException;

import com.tweetapp.model.TweetModel;
import com.tweetapp.model.UserModel;

public interface IUserService 
{
	public void insert(UserModel user) throws SQLException ;
	
	public void updatepassword(String username,String pwd)throws SQLException;
	
	public boolean validateUser(String email) throws Exception;
	
	public String validatePassword(String email) throws Exception;
	
	public void insertTweet(TweetModel tweet) throws SQLException;
	
	public void viewAllTweets() throws SQLException;
	
	public void viewAllUsers() throws SQLException;
	
	public void viewMyTweet(String username) throws SQLException;
	
	public void setLoginStatus(String mail,String status);
}
