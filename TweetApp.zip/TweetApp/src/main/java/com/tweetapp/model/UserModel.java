package com.tweetapp.model;

import java.time.LocalDate;
import java.util.Date;

public class UserModel 
{
	
	private String firstname;
	private String lastname;
	private String gender;
	private Date dob;
	private String gmail;
	private String password;
	private String oldpassword;
	private String status;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOldpassword()
	{
		return oldpassword;
	}
	public void setOldpassword(String oldpassword) 
	{
		this.oldpassword = oldpassword;
	}
	public String getFirstname() 
	{
		return firstname;
	}
	
	public void setFirstname(String firstname) 
	{
		this.firstname = firstname;
	}
	public String getLastname()
	{
		return lastname;
	}
	public void setLastname(String lastname) 
	{
		this.lastname = lastname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender)
	{
		this.gender = gender;
	}
	public  Date getDob() 
	{
		return  dob;
	}
	public void setDob(Date date) 
	{
		this.dob = date;
	}
	public String getGmail() 
	{
		return gmail;
	}
	public void setGmail(String gmail) 
	{
		this.gmail = gmail;
	}
	public String getPassword()
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
	public UserModel()
	{
		super();
		
	}
	public UserModel(String firstname, String lastname, String gender, Date dob, String gmail, String password,String oldpassword,String status) 
	{
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.dob = dob;
		this.gmail = gmail;
		this.password = password;
		this.oldpassword=oldpassword;
		this.status=status;
	}

}
