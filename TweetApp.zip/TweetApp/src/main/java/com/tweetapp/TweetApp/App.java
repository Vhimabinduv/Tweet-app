package com.tweetapp.TweetApp;


import java.util.Scanner;
import com.tweetapp.model.TweetModel;
import com.tweetapp.model.UserModel;
import com.tweetapp.pages.ForgotPassword;
import com.tweetapp.pages.TweetPage;
import com.tweetapp.pages.UserLogin;
import com.tweetapp.pages.UserRegistration;
import com.tweetapp.service.UserServiceImpl;



public class App 
{
    public static void main( String[] args ) throws Exception
    {
    	Scanner scan= new Scanner(System.in);
    	
    	UserServiceImpl service= new UserServiceImpl();
    	UserModel user =new UserModel();
    	TweetModel tweet= new TweetModel();
    	TweetPage tp=new TweetPage();
    	UserRegistration ur= new UserRegistration();
    	ForgotPassword fr= new ForgotPassword();
    	String status="loggedout";
    	String option="";
		do
		{
			System.out.println( "Select Your Choice" );
			System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\");
			System.out.println("1.Register");
			System.out.println("2.Login");
			System.out.println("3.Forgot Password");
			System.out.println("4.exit");
			option=scan.nextLine();
			if(option.equalsIgnoreCase("1"))
			{
				user=ur.register();
				service.insert(user);
			}
			if(option.equalsIgnoreCase("2"))
			{
				String option1="";
				UserLogin ul= new UserLogin();
				if(ul.login()==true)
				{
					do
					{
						System.out.println("select Option to perform");
						System.out.println("1.Post your Tweet");
						System.out.println("2.View all my tweets");
						System.out.println("3.View all tweets");
						System.out.println("4.View all users");
						System.out.println("5.Reset your Password");
						System.out.println("6.Logout");
						option1=scan.nextLine();
						if(option1.equalsIgnoreCase("1"))
						{
							tweet=tp.postTweet();
							service.insertTweet(tweet);
						}
						if(option1.equalsIgnoreCase("2"))
						{
							String username=ul.getUser();
							service.viewMyTweet(username);
						}
						if(option1.equalsIgnoreCase("3"))
						{
							service.viewAllTweets();
						}
						if(option1.equalsIgnoreCase("4"))
						{
							service.viewAllUsers();
						}
						if(option1.equalsIgnoreCase("5"))
						{
							fr.resetPassword();
						}
						if(option1.equalsIgnoreCase("6"))
						{
							String username=ul.getUser();
							service.setLoginStatus(username, status);
						}
				}while(!option1.equals("6"));
			}
		}
		if(option.equalsIgnoreCase("3"))
		{
        	fr.password();
		}
	}while(!option.equals("4"));
  }
}



